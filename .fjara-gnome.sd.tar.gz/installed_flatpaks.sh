flatpak install --system com.slack.Slack -y
flatpak install --system io.github.vikdevelop.SaveDesktop -y
flatpak install --system org.gnome.ColorViewer -y
